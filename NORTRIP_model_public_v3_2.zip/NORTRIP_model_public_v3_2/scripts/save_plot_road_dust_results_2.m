%==========================================================================
%NORTRIP model
%SUBROUTINE: save_plot_road_dust_results_v2
%VERSION: 2, 27.08.2012
%AUTHOR: Bruce Rolstad Denby (bde@nilu.no)
%DESCRIPTION: Saves figures made by the NORTRIP model
%==========================================================================

if exist('plot_figure'),
    for i=1:length(plot_figure),
    if plot_figure(i)==1,
        plot_name=get(handle_plot(i),'Name');
        filename_outputfigures=[title_str,'_',char(av_str{plot_type_flag}),'_fig'];
        filename=[path_outputfig,filename_outputfigures,'_',num2str(i),'_',plot_name];
        %saveas(i,filename,'tiff');
        saveas(i,filename,'png');
    end
    end
end